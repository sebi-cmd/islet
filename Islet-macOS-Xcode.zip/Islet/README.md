# Islet — Dynamic Island für macOS

Eine native SwiftUI/AppKit-Demo für eine saubere Dynamic-Island-artige Oberfläche am oberen Bildschirmrand.

## Enthalten
- Floating Notch/Island-Overlay
- Klick zum Expandieren
- Apple Music + Spotify Play/Pause, Zurück, Weiter
- Aktueller Titel/Künstler
- Systemlautstärke + Mute
- Batterieanzeige
- Menüleisten-Icon
- Autostart bei Anmeldung über `SMAppService`
- Transparente, native macOS-Optik mit Material/Animationen

## Starten
1. `Islet.xcodeproj` in Xcode auf einem Mac öffnen.
2. Als Ziel einen Mac auswählen.
3. **Signing & Capabilities**: ein persönliches Team für das Target auswählen.
4. Build & Run.
5. Beim ersten Zugriff auf Musik kann macOS eine Berechtigung für Apple Events abfragen.

## Autostart
Islet versucht beim ersten Start, sich über `SMAppService.mainApp` als Login Item zu registrieren. Das lässt sich über das Menüleisten-Menü wieder deaktivieren.

## Hinweise
Das Projekt ist absichtlich ohne private Apple-Frameworks gebaut. Die Musikwiedergabe wird über AppleScript gesteuert. Dadurch funktioniert die Basis mit Apple Music und Spotify, soweit die jeweilige App installiert und die Automationsberechtigung erteilt ist.

Für eine echte „Perch“-ähnliche nächste Version wären mögliche Erweiterungen: Album-Art, Kalender, Timer, AirPods/Bluetooth-Akku, Focus-Modus, AirDrop/Dateitransfer-Status, Downloads, Shortcuts und frei konfigurierbare Widgets.
