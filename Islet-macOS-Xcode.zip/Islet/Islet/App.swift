import SwiftUI
import AppKit
import ServiceManagement

@main
struct IsletApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) private var appDelegate

    var body: some Scene {
        Settings { EmptyView() }
    }
}

final class AppDelegate: NSObject, NSApplicationDelegate {
    private var islandWindow: IslandWindow!
    private var statusItem: NSStatusItem!
    private let music = MusicController()

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.accessory)
        setupStatusItem()
        showIsland()
        AutoLauncher.enable()
    }

    private func showIsland() {
        islandWindow = IslandWindow(music: music)
        islandWindow.orderFrontRegardless()
    }

    private func setupStatusItem() {
        statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
        statusItem.button?.image = NSImage(systemSymbolName: "waveform", accessibilityDescription: "Islet")

        let menu = NSMenu()
        menu.addItem(NSMenuItem(title: "Islet öffnen", action: #selector(openIsland), keyEquivalent: "o"))
        menu.addItem(NSMenuItem.separator())
        let launch = NSMenuItem(title: "Bei Anmeldung starten", action: #selector(toggleLaunch), keyEquivalent: "")
        launch.state = AutoLauncher.isEnabled ? .on : .off
        menu.addItem(launch)
        menu.addItem(NSMenuItem.separator())
        menu.addItem(NSMenuItem(title: "Beenden", action: #selector(quit), keyEquivalent: "q"))
        statusItem.menu = menu
    }

    @objc private func openIsland() {
        islandWindow?.orderFrontRegardless()
    }

    @objc private func toggleLaunch(_ sender: NSMenuItem) {
        AutoLauncher.setEnabled(!AutoLauncher.isEnabled)
        sender.state = AutoLauncher.isEnabled ? .on : .off
    }

    @objc private func quit() {
        NSApp.terminate(nil)
    }
}

enum AutoLauncher {
    static var isEnabled: Bool {
        SMAppService.mainApp.status == .enabled
    }

    static func enable() {
        guard !isEnabled else { return }
        try? SMAppService.mainApp.register()
    }

    static func setEnabled(_ enabled: Bool) {
        do {
            if enabled { try SMAppService.mainApp.register() }
            else { try SMAppService.mainApp.unregister() }
        } catch {
            NSLog("Autostart error: \(error.localizedDescription)")
        }
    }
}
