import Foundation
import IOKit.ps

struct BatteryInfo {
    let percent: Int

    static var current: BatteryInfo {
        guard let blob = IOPSCopyPowerSourcesInfo()?.takeRetainedValue(),
              let list = IOPSCopyPowerSourcesList(blob)?.takeRetainedValue() as? [CFTypeRef],
              let first = list.first,
              let description = IOPSGetPowerSourceDescription(blob, first)?.takeUnretainedValue() as? [String: Any],
              let capacity = description[kIOPSCurrentCapacityKey] as? Int,
              let max = description[kIOPSMaxCapacityKey] as? Int,
              max > 0 else { return BatteryInfo(percent: 100) }
        return BatteryInfo(percent: Int(Double(capacity) / Double(max) * 100.0))
    }
}
