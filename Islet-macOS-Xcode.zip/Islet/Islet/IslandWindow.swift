import SwiftUI
import AppKit

final class IslandWindow: NSPanel {
    private let model: IslandModel

    init(music: MusicController) {
        self.model = IslandModel(music: music)
        let screen = NSScreen.main ?? NSScreen.screens.first!
        let width: CGFloat = 380
        let height: CGFloat = 62
        let x = screen.frame.midX - width / 2
        let y = screen.frame.maxY - height - 7

        super.init(contentRect: NSRect(x: x, y: y, width: width, height: height),
                   styleMask: [.borderless, .nonactivatingPanel],
                   backing: .buffered,
                   defer: false)

        isFloatingPanel = true
        level = .statusBar
        collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary, .stationary]
        backgroundColor = .clear
        isOpaque = false
        hasShadow = false
        ignoresMouseEvents = false
        hidesOnDeactivate = false
        becomesKeyOnlyIfNeeded = true
        contentView = NSHostingView(rootView: IslandView(model: model))
    }

    override var canBecomeKey: Bool { true }
    override var canBecomeMain: Bool { false }
}

@MainActor
final class IslandModel: ObservableObject {
    @Published var expanded = false
    @Published var nowPlaying = NowPlaying.empty
    @Published var battery = BatteryInfo.current
    @Published var volume: Double = SystemAudio.volume
    @Published var muted: Bool = SystemAudio.isMuted
    @Published var currentDate = Date()

    let music: MusicController
    private var timer: Timer?

    init(music: MusicController) {
        self.music = music
        refresh()
        timer = Timer.scheduledTimer(withTimeInterval: 2, repeats: true) { [weak self] _ in
            Task { @MainActor in self?.refresh() }
        }
    }

    func refresh() {
        nowPlaying = music.nowPlaying()
        battery = BatteryInfo.current
        currentDate = Date()
        volume = SystemAudio.volume
        muted = SystemAudio.isMuted
    }

    func toggleExpanded() {
        withAnimation(.spring(response: 0.32, dampingFraction: 0.82)) { expanded.toggle() }
    }
}

struct IslandView: View {
    @ObservedObject var model: IslandModel

    var body: some View {
        VStack(spacing: 0) {
            compactBar
            if model.expanded {
                expandedPanel
                    .transition(.move(edge: .top).combined(with: .opacity))
            }
        }
        .padding(7)
        .frame(width: model.expanded ? 470 : 380, height: model.expanded ? 350 : 76, alignment: .top)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: model.expanded ? 28 : 34, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: model.expanded ? 28 : 34, style: .continuous).stroke(.white.opacity(0.10)))
        .shadow(color: .black.opacity(0.35), radius: 24, y: 12)
        .contentShape(RoundedRectangle(cornerRadius: 30))
        .onTapGesture { model.toggleExpanded() }
    }

    private var compactBar: some View {
        HStack(spacing: 10) {
            ZStack {
                Circle().fill(.white.opacity(0.10))
                Image(systemName: model.nowPlaying.isPlaying ? "waveform" : "music.note")
                    .font(.system(size: 14, weight: .semibold))
            }
            .frame(width: 38, height: 38)

            VStack(alignment: .leading, spacing: 2) {
                Text(model.nowPlaying.title.isEmpty ? "Bereit" : model.nowPlaying.title)
                    .font(.system(size: 13, weight: .semibold))
                    .lineLimit(1)
                Text(model.nowPlaying.artist.isEmpty ? "Islet" : model.nowPlaying.artist)
                    .font(.system(size: 11))
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
            }

            Spacer(minLength: 4)

            Image(systemName: "battery.100")
                .foregroundStyle(.secondary)
            Text("\(model.battery.percent)%")
                .font(.system(size: 11, weight: .medium, design: .rounded))
                .foregroundStyle(.secondary)

            Image(systemName: model.expanded ? "chevron.up" : "chevron.down")
                .font(.system(size: 10, weight: .bold))
                .foregroundStyle(.secondary)
                .padding(.leading, 3)
        }
        .padding(.horizontal, 8)
        .frame(height: 50)
    }

    private var expandedPanel: some View {
        VStack(spacing: 12) {
            Divider().opacity(0.12)
            HStack(spacing: 12) {
                RoundedRectangle(cornerRadius: 13)
                    .fill(.white.opacity(0.08))
                    .frame(width: 72, height: 72)
                    .overlay(Image(systemName: "music.note.list").font(.system(size: 28)).foregroundStyle(.secondary))

                VStack(alignment: .leading, spacing: 5) {
                    Text(model.nowPlaying.title.isEmpty ? "Keine Wiedergabe" : model.nowPlaying.title)
                        .font(.system(size: 17, weight: .bold))
                        .lineLimit(1)
                    Text(model.nowPlaying.artist.isEmpty ? "Öffne Apple Music oder Spotify" : model.nowPlaying.artist)
                        .font(.system(size: 13))
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
                Spacer()
            }

            HStack(spacing: 16) {
                controlButton("backward.fill") { model.music.previous() }
                controlButton(model.nowPlaying.isPlaying ? "pause.fill" : "play.fill", size: 19) { model.music.playPause() }
                controlButton("forward.fill") { model.music.next() }
            }

            HStack(spacing: 10) {
                Image(systemName: "speaker.fill").font(.system(size: 11)).foregroundStyle(.secondary)
                Slider(value: Binding(get: { model.volume }, set: { model.volume = $0; SystemAudio.setVolume($0) }), in: 0...100)
                Image(systemName: "speaker.wave.3.fill").font(.system(size: 11)).foregroundStyle(.secondary)
            }

            HStack(spacing: 8) {
                infoTile(icon: "clock.fill", title: model.currentDate.formatted(date: .omitted, time: .shortened), subtitle: model.currentDate.formatted(date: .abbreviated, time: .omitted))
                infoTile(icon: "battery.100", title: "\(model.battery.percent)%", subtitle: "Batterie")
                infoTile(icon: model.muted ? "speaker.slash.fill" : "speaker.wave.2.fill", title: "\(Int(model.volume))%", subtitle: model.muted ? "Stumm" : "Lautstärke")
            }
        }
        .padding(.horizontal, 10)
        .padding(.bottom, 8)
    }

    private func controlButton(_ icon: String, size: CGFloat = 14, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: icon).font(.system(size: size, weight: .semibold))
                .frame(width: 44, height: 34)
                .background(.white.opacity(0.08), in: Capsule())
        }
        .buttonStyle(.plain)
    }

    private func infoTile(icon: String, title: String, subtitle: String) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            Image(systemName: icon).font(.system(size: 13, weight: .semibold))
            Text(title).font(.system(size: 12, weight: .bold, design: .rounded))
            Text(subtitle).font(.system(size: 9, weight: .medium)).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(10)
        .background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 13, style: .continuous))
    }

    private func quickTile(icon: String, title: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(spacing: 5) {
                Image(systemName: icon).font(.system(size: 13, weight: .semibold))
                Text(title).font(.system(size: 10, weight: .medium))
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 8)
            .background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
        }
        .buttonStyle(.plain)
    }
}
