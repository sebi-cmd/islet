import Foundation
import AppKit

struct NowPlaying: Equatable {
    var title = ""
    var artist = ""
    var isPlaying = false
    static let empty = NowPlaying()
}

final class MusicController {
    func nowPlaying() -> NowPlaying {
        if let music = scriptResult(for: """
        tell application "Music"
            if it is running then
                set pstate to player state as string
                set t to ""
                set a to ""
                try
                    set t to name of current track
                    set a to artist of current track
                end try
                return pstate & "|||" & t & "|||" & a
            end if
        end tell
        """) {
            let parts = music.split(separator: "|||", omittingEmptySubsequences: false).map(String.init)
            if parts.count >= 3 { return NowPlaying(title: parts[1], artist: parts[2], isPlaying: parts[0] == "playing") }
        }

        if let spotify = scriptResult(for: """
        tell application "Spotify"
            if it is running then
                set pstate to player state as string
                return pstate & "|||" & name of current track & "|||" & artist of current track
            end if
        end tell
        """) {
            let parts = spotify.split(separator: "|||", omittingEmptySubsequences: false).map(String.init)
            if parts.count >= 3 { return NowPlaying(title: parts[1], artist: parts[2], isPlaying: parts[0] == "playing") }
        }
        return .empty
    }

    func playPause() {
        run("tell application \"Music\" to playpause")
        run("tell application \"Spotify\" to playpause")
    }
    func next() {
        run("tell application \"Music\" to next track")
        run("tell application \"Spotify\" to next track")
    }
    func previous() {
        run("tell application \"Music\" to previous track")
        run("tell application \"Spotify\" to previous track")
    }

    private func run(_ source: String) {
        let script = NSAppleScript(source: source)
        var error: NSDictionary?
        _ = script?.executeAndReturnError(&error)
    }

    private func scriptResult(for source: String) -> String? {
        let script = NSAppleScript(source: source)
        var error: NSDictionary?
        return script?.executeAndReturnError(&error)?.stringValue
    }
}

struct SystemAudio {
    static var volume: Double {
        let p = Process()
        p.executableURL = URL(fileURLWithPath: "/usr/bin/osascript")
        p.arguments = ["-e", "output volume of (get volume settings)"]
        let pipe = Pipe(); p.standardOutput = pipe
        try? p.run(); p.waitUntilExit()
        return Double(String(data: pipe.fileHandleForReading.readDataToEndOfFile(), encoding: .utf8)?.trimmingCharacters(in: .whitespacesAndNewlines) ?? "50") ?? 50
    }

    static var isMuted: Bool {
        let p = Process(); p.executableURL = URL(fileURLWithPath: "/usr/bin/osascript")
        p.arguments = ["-e", "output muted of (get volume settings)"]
        let pipe = Pipe(); p.standardOutput = pipe; try? p.run(); p.waitUntilExit()
        return (String(data: pipe.fileHandleForReading.readDataToEndOfFile(), encoding: .utf8) ?? "false").contains("true")
    }

    static func setVolume(_ value: Double) {
        let v = Int(max(0, min(100, value)))
        run("set volume output volume \(v)")
    }

    static func toggleMute() { run("set volume output muted not (output muted of (get volume settings))") }

    private static func run(_ command: String) {
        let p = Process(); p.executableURL = URL(fileURLWithPath: "/usr/bin/osascript")
        p.arguments = ["-e", command]; try? p.run()
    }
}
